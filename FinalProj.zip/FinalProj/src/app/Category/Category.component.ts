import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { NgModule, Directive} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {RouterModule,Router,Routes} from "@angular/router";
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-categories',
  templateUrl: './Category.component.html',
  styleUrls: ['./Category.component.css'],
   
})
export class categoriesComponent {

  categories: any[]=[
    {
      "category_id":"1",
      "category_name":"Running"
    },
    {
      "category_id":"2",
      "category_name":"Jogging"
    },
    {
      "category_id":"3",
      "category_name":"Cycling"
    }
  ];
 
 
}
