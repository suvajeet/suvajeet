import { Component, OnInit, group, Input, Output } from '@angular/core';
import {Observable} from "rxjs/Observable";
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { NgModule, Directive} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {RouterModule,Router,Routes,ActivatedRoute} from "@angular/router";


import { FormsModule } from '@angular/forms';
import { categoriesComponent } from '../Category/Category.component';
import { WorkoutComponent } from '../CreateWorkout/CreateWorkout.component';


@Component({
  selector: 'app-createWorkout',
  templateUrl: './View.component.html',
  styleUrls: ['./View.component.css']
})


export class ViewComponent{

}
