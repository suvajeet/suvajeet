import { Component, OnInit, group, Input, Output } from '@angular/core';
import {Observable} from "rxjs/Observable";
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { NgModule, Directive} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {RouterModule,Router,Routes,ActivatedRoute} from "@angular/router";


import { FormsModule } from '@angular/forms';
import { categoriesComponent } from '../Category/Category.component';


@Component({
  selector: 'app-createWorkout',
  templateUrl: './CreateWorkout.component.html',
  styleUrls: ['./CreateWorkout.component.css']
})


export class WorkoutComponent{

  workouts: any[]=[
    {
      "workout_id":"100",
      "workout_title":"Run for 10 mins",
      "workout_note":"Run for 10 mins in the morning",
      "workout_calBurnt":"100",
      "workout_category":"Running"
    },
    {
      "workout_id":"101",
      "workout_title":"Jogging for 10 mins",
      "workout_note":"Jogging for 10 mins in the evening",
      "workout_calBurnt":"80",
      "workout_category":"Jogging"
    }
  ];
}
